package com.testvagrant.rcb.service;

import com.testvagrant.rcb.model.Team;

public interface TeamService {

	public void add(Team team);

}
