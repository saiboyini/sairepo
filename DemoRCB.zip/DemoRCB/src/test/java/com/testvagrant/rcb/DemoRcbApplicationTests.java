package com.testvagrant.rcb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoRcbApplicationTests {

	@Test
	void contextLoads() {
	}

}
